// ##############################################################
// REQUIRE MODULES
// ##############################################################s
const pool = require('../services/db');

// ##############################################################
// DEFINE INSERT OPERATION FOR TREE
// ##############################################################
module.exports.insertTree = (data, callback) => {
  const SQLSTATEMENT = `
  INSERT INTO Tree (species, age, height, user_id)
  VALUES (?, ?, ?, ?)
  `;
  const VALUES = [data.species, data.age, data.height, data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
}

// ##############################################################
// DEFINE SELECT ALL OPERATIONS FOR TREE
// ##############################################################
module.exports.selectAllTrees = (callback) => {
    const SQLSTATEMENT = `
    SELECT * FROM Tree
    `;

  pool.query(SQLSTATEMENT, callback);

};
// ##############################################################
// DEFINE SELECT BY ID OPERATIONS FOR TREE
// ##############################################################
module.exports.selectTree = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT * FROM Tree
  WHERE id = ?`;

  const VALUES = [data.id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};


// ##############################################################
// DEFINE UPDATE OPERATIONS FOR TREE
// ##############################################################
module.exports.deleteById = (data, callback) =>
{
const SQLSTATMENT = `
    DELETE FROM Tree
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE DELETE OPERATIONS FOR TREE
// ##############################################################
module.exports.updateTree = (data, callback) => {
  const SQLSTATEMENT = `
    UPDATE Tree
    SET species = ?, age = ?, height = ?, user_id = ?
    WHERE id = ?
    `;
  const VALUES = [data.species, data.age, data.height, data.user_id, data.id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};
