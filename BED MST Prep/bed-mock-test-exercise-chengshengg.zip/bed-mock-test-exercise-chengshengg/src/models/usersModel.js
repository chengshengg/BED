// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require('../services/db');

// ##############################################################
// DEFINE SELECT TREES BY USER ID
// ##############################################################
module.exports.selectUserTrees = (data, callback) => {

    const SQLSTATMENT = `
    SELECT * FROM Tree
    INNER JOIN User
    ON User.id = Tree.user_id 
    WHERE id = ?;
    `;

    const VALUES = [data.id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

// ##############################################################
// DEFINE WATER TREE BY USER ID
// ##############################################################


// ##############################################################
// DEFINE MODEL FOR GET AVERAGE AGE OF TREES OWNED BY USER
// ##############################################################
