// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require("express");
const router = express.Router();

// ##############################################################
// CREATE ROUTER
// ##############################################################
const treesController = require("../controllers/treesController")

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.get("/:id", 
    treesController.getTree
);

router.get("",
    treesController.getAllTrees
)

router.post("",
    treesController.createTree
)

router.delete("/:id",
    treesController.deleteTree
)

router.put("/:id",
    treesController.updateTree
)

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router