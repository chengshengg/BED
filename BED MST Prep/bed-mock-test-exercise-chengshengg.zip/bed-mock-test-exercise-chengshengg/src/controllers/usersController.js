// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/usersModel");

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ TREE BY USERID
// ##############################################################
module.exports.getUserTrees = (req, res, next) => {

  const data = {
    id: res.locals.id || req.params.id
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error getTree:", error);
      res.status(500).json(error);
    } else {
      if (results.length == 0) {
        res.status(404).json({
          message: "Tree not found",
        });
      }else {
          res.locals.tree = results[0]
          res.status(200).json(results)
      }
    };
  }
  model.selectUserTrees(data, callback);
};

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR WATER TREE BY USERID
// ##############################################################


// ##############################################################
// DEFINE MIDDLEWARE FUNCTION FOR CHECK TREE OWNERSHIP
// ##############################################################


// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR GET AVERAGE AGE OF 
// TREES OWNED BY USER
// ##############################################################
